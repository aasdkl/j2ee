package vo;

public class CourseVO {

}
