package vo;

public class StudentVO {

}
